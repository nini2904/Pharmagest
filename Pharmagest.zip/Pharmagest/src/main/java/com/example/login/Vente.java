package com.example.login;

import java.util.Date;

public class Vente {

    private int num_vente;
    private Date date_vente;
    private String status;
    private double montant;
    private int utilisateur_id;

    public Vente(int NoVente, Date DateVente, String status, double montant, int utilisateur_id) {
        this.num_vente = NoVente;
        this.date_vente = DateVente;
        this.status = status;
        this.montant = montant;
        this.utilisateur_id = utilisateur_id;
    }

    // Getters and setters

    public int getNum_vente() {
        return num_vente;
    }

    public void setNum_vente(int num_vente) {
        this.num_vente = num_vente;
    }

    public Date getDate_vente() {
        return date_vente;
    }

    public void setDate_vente(Date date_vente) {
        this.date_vente = date_vente;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

    public int getUtilisateur_id() {
        return utilisateur_id;
    }

    public void setUtilisateur_id(int utilisateur_id) {
        this.utilisateur_id = utilisateur_id;
    }
}
