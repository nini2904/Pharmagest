package com.example.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    public Connection databaselink;

    public Connection getConnection() {
     /*   String databaseName ="PharmaGest";
        String databaseUser="postgres";
        String databasePassword="091105";
        String url="jdbc:postgresql://localhost:5432/" + databaseName; */
        String databaseName ="supercarnanjanee_pharmagestdb";
        String databaseUser="supercarnanjanee_admin";
        String databasePassword="nanjaneeK29";
        String url="jdbc:postgresql://postgresql-supercarnanjanee.alwaysdata.net:5432/" + databaseName;

        try {
            Class.forName("org.postgresql.Driver");
            databaselink=DriverManager.getConnection(url,databaseUser,databasePassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return databaselink;
    }
}
