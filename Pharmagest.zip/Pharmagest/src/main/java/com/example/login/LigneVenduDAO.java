package com.example.login;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class LigneVenduDAO {

    public List<LigneVendu> getLignesVenduesParVente(int numVente) {
        List<LigneVendu> liste = new ArrayList<>();
        String sql = "SELECT * FROM ligne_vendu WHERE num_vente = ?";

        try (Connection conn = new DatabaseConnection().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, numVente);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                LigneVendu ligne = new LigneVendu(
                        rs.getInt("ligne_vendu_id"),
                        rs.getInt("num_vente"),
                        rs.getString("medicament_dci"),
                        rs.getInt("qte_vendue"),
                        rs.getDouble("prixunit_vente")
                );
                liste.add(ligne);
            }

            rs.close();

        } catch (SQLException e) {
            System.out.println("Erreur lors de la récupération des lignes vendues : " + e.getMessage());
            e.printStackTrace();
        }

        return liste;
    }

}
