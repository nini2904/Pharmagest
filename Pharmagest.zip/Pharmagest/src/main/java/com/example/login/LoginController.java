package com.example.login;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginController {

    private Stage stage;
    private Scene scene;

    @FXML
    private Button cancelButton;
    @FXML
    private Label loginMessageLabel;
    @FXML
    private Label usernameLabel; // Label pour afficher le nom d'utilisateur
    @FXML
    private Button loginButton;
    @FXML

    private TextField usernameTextfield;
    @FXML
    private PasswordField passwordPasswordfield;



    @FXML
    public void loginButtonOnAction(ActionEvent e) throws IOException {
        if (!usernameTextfield.getText().isBlank() && !passwordPasswordfield.getText().isBlank()) {
            // Validation BDD
            validateLogin(e);
        } else {
            loginMessageLabel.setText("Please enter username and password!");
        }
    }

    public void validateLogin(ActionEvent e) {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String verifyLogin = "SELECT Count(0) FROM public.\"utilisateur\" WHERE \"identifiant\"='" +
                usernameTextfield.getText() + "' AND \"mot_de_passe\"='" +
                passwordPasswordfield.getText() + "';";

        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(verifyLogin);

            while (queryResult.next()) {
                if (queryResult.getInt(1) == 1) {
                    loginMessageLabel.setText("Bienvenu à l'application");

                    // Charger le Dashboard avec le contrôleur
                    FXMLLoader fxmlLoader = new FXMLLoader(LoginApplication.class.getResource("Dashboard.fxml"));
                    Parent dashboardParent = fxmlLoader.load();

                    // Récupérer le contrôleur du Dashboard et passer le nom d'utilisateur
                    LoginController dashboardController = fxmlLoader.getController();
                    dashboardController.setUsername(usernameTextfield.getText());

                    // Créer la scène et l'afficher
                    Scene scene = new Scene(dashboardParent, 900, 600);
                    stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
                    stage.setTitle("Dashboard");
                    stage.setScene(scene);
                    stage.show();
                } else {
                    loginMessageLabel.setText("Login invalide. Veuillez re-essayer.");
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // Méthode pour définir le nom d'utilisateur dans le Label du Dashboard
    public void setUsername(String username) {
        if (usernameLabel != null) {
            usernameLabel.setText(username);
        }
    }

    @FXML
    public void cancelButtonOnAction(ActionEvent e) {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    public void MaintenanceOnAction(ActionEvent actionEvent) {
        String maintenanceFXML = "Maintenance.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(maintenanceFXML));
        try {
            Parent maintenanceParent = loader.load();
            Scene maintenanceScene = new Scene(maintenanceParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(maintenanceScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + maintenanceFXML, e);
        }
    }

    public void VenteOnAction(ActionEvent actionEvent) {
        String venteFXML = "Vente.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(venteFXML));
        try {
            Parent venteParent = loader.load();
            Scene venteScene = new Scene(venteParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(venteScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + venteFXML, e);
        }
    }
    public void CaisseOnAction(ActionEvent actionEvent) {
        String caisseFXML = "Caisse.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(caisseFXML));
        try {
            Parent caisseParent = loader.load();
            Scene caisseScene = new Scene(caisseParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(caisseScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + caisseFXML, e);
        }
    }
    public void RetourOnAction(ActionEvent actionEvent) {
        String dashboardFXML = "Dashboard.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(dashboardFXML));
        try {
            Parent dashboardParent = loader.load();
            Scene dashboardScene = new Scene(dashboardParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + dashboardFXML, e);
        }
    }

    @FXML
    public void changeloginButtonOnAction(ActionEvent e) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginApplication.class.getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 528, 488);
        stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }


}


