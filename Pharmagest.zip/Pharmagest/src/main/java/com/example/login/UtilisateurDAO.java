package com.example.login;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UtilisateurDAO {
    private Connection connection;
    public UtilisateurDAO (Connection connection) {
        this.connection = connection; // Utilisation de la connexion partagée
    }
    // Récupérer tous les médicaments de la base de données
    public List<Utilisateur> getAllUtilisateurs() {
        List<Utilisateur> utilisateurs = new ArrayList<>();
        String query = "SELECT * FROM utilisateur"; // Change selon ton schéma

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                // Vérifie que les noms de colonnes correspondent à ceux de ta base de données
                Utilisateur med = new Utilisateur(
                        rs.getString("identifiant"),  // Assure-toi que le nom de la colonne DCI est correct
                        rs.getString("prenom_per"),  // nom_commercial dans ta table
                        rs.getString("nom_per"),
                        rs.getDate("date_naissance"),  // prixUnit_vente dans ta table
                        rs.getInt("telephone"),  // prixUnit_achat dans ta table
                        rs.getString("email"),  // qte_Stock dans ta table
                        rs.getString("adresse"), // num_famille fait référence à une autre table famille
                        rs.getString("mot_de_passe") // nom_forme fait référence à une autre table forme
                );
                utilisateurs.add(med);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return utilisateurs;
    }
    public Utilisateur getUtilisateurByIdentifiant(String identifiant) {
        Utilisateur utilisateur = null;
        String query = "SELECT * FROM utilisateur WHERE identifiant = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, identifiant);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                utilisateur = new Utilisateur(
                        rs.getString("identifiant"),
                        rs.getString("prenom_per"),
                        rs.getString("nom_per"),
                        rs.getDate("date_naissance"),
                        rs.getInt("telephone"),
                        rs.getString("email"),
                        rs.getString("adresse"),
                        rs.getString("mot_de_passe")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Tu peux aussi faire un `System.out.println(e.getMessage());`
        }

        return utilisateur;
    }

    // Ajouter un utilisateur dans la base de données
    public void addUtilisateur(Utilisateur utilisateur) {
        String query = "INSERT INTO utilisateur (identifiant, prenom_per,nom_per, date_naissance, telephone, email, adresse, mot_de_passe) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, utilisateur.getIdentifiant());
            stmt.setString(2, utilisateur.getPrenom_per());
            stmt.setString(3, utilisateur.getNom_per());
            stmt.setDate(4, utilisateur.getDate_naissance());
            stmt.setInt(5, utilisateur.getTelephone());
            stmt.setString(6, utilisateur.getEmail());
            stmt.setString(7, utilisateur.getAdresse());
            stmt.setString(8, utilisateur.getMot_de_passe());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Mettre à jour un médicament dans la base de données
    public void updateUtilisateur(Utilisateur utilisateur) {
        String query = "UPDATE utilisateur SET  prenom_per = ?, nom_per = ?, date_naissance = ?, telephone = ?, email = ?, adresse = ?, mot_de_passe = ? WHERE identifiant = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, utilisateur.getPrenom_per());
            stmt.setString(2, utilisateur.getNom_per());
            stmt.setDate(3, new java.sql.Date(utilisateur.getDate_naissance().getTime()));
            stmt.setInt(4, utilisateur.getTelephone());
            stmt.setString(5, utilisateur.getEmail());
            stmt.setString(6, utilisateur.getAdresse());
            stmt.setString(7, utilisateur.getMot_de_passe());
            stmt.setString(8, utilisateur.getIdentifiant()); // à la fin, pour le WHERE
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void deleteUtilisateur(Utilisateur utilisateur) {
        String query = "DELETE FROM utilisateur WHERE identifiant = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, utilisateur.getIdentifiant());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
