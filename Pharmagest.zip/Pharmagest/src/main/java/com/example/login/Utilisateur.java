package com.example.login;

import java.sql.Date;

public class Utilisateur {
    private String identifiant;
    private String prenom_per;
    private String nom_per;
    private Date date_naissance; // Utilisation de java.sql.Date
    private int telephone;
    private String email;
    private String adresse;
    private String mot_de_passe;

    public Utilisateur(String identifiant, String prenom_per, String nom_per, Date date_naissance,
                       int telephone, String email, String adresse, String mot_de_passe) {
        this.identifiant = identifiant;
        this.prenom_per = prenom_per;
        this.nom_per = nom_per;
        this.date_naissance = date_naissance;
        this.telephone = telephone;
        this.email = email;
        this.adresse = adresse;
        this.mot_de_passe = mot_de_passe;
    }

    public String getIdentifiant() {
        return identifiant;
    }

    public void setIdentifiant(String identifiant) {
        this.identifiant = identifiant;
    }

    public String getPrenom_per() {
        return prenom_per;
    }

    public void setPrenom_per(String prenom_per) {
        this.prenom_per = prenom_per;
    }

    public String getNom_per() {
        return nom_per;
    }

    public void setNom_per(String nom_per) {
        this.nom_per = nom_per;
    }

    public Date getDate_naissance() {
        return date_naissance;
    }

    public void setDate_naissance(Date date_naissance) {
        this.date_naissance = date_naissance;
    }

    public int getTelephone() {
        return telephone;
    }

    public void setTelephone(int telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getMot_de_passe() {
        return mot_de_passe;
    }

    public void setMot_de_passe(String mot_de_passe) {
        this.mot_de_passe = mot_de_passe;
    }
}
