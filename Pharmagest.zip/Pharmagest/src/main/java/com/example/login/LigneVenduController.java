package com.example.login;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.FXCollections;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class LigneVenduController {
    @FXML
    private TableView<LigneVendu> tableLignes;

    @FXML
    private TableColumn<LigneVendu, Integer> colId;

    @FXML
    private TableColumn<LigneVendu, Integer> colVente;

    @FXML
    private TableColumn<LigneVendu, String> colMedicament;

    @FXML
    private TableColumn<LigneVendu, Integer> colQte;

    @FXML
    private TableColumn<LigneVendu, Double> colPrix;

    @FXML
    private TableView<Vente> tableVentes;
    @FXML
    private TableColumn<Vente, Integer> colNumVente;

    @FXML
    private TableColumn<Vente, Double> colTotalVente;
    @FXML
    private TextArea consoleOutput;

    public void initialize() {
        // Remplissage de la table des ventes
        VenteDAO venteDAO = new VenteDAO();
        colNumVente.setCellValueFactory(new PropertyValueFactory<>("num_vente"));
        colTotalVente.setCellValueFactory(new PropertyValueFactory<>("montant"));
        tableVentes.getItems().setAll(venteDAO.getVentes());

        // Remplissage de la table des lignes vendues
        LigneVenduDAO dao = new LigneVenduDAO();
        colId.setCellValueFactory(new PropertyValueFactory<>("ligne_vendu_id"));
        colVente.setCellValueFactory(new PropertyValueFactory<>("num_vente"));
        colMedicament.setCellValueFactory(new PropertyValueFactory<>("medicament_dci"));
        colQte.setCellValueFactory(new PropertyValueFactory<>("qte_vendue"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prixunit_vente"));

        // Tu peux mettre toutes les lignes au début, ou aucune :
        tableLignes.getItems().clear(); // ou .setAll(dao.getLignesVendues());

        tableVentes.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                Vente selectedVente = tableVentes.getSelectionModel().getSelectedItem();
                if (selectedVente != null) {
                    int numVente = selectedVente.getNum_vente();
                    double montant = selectedVente.getMontant();

                    tableLignes.getItems().setAll(dao.getLignesVenduesParVente(numVente));
                    consoleOutput.setText("Montant total : " + montant + " Rs");
                }
            }
        });

    }

    public void RetourOnAction(ActionEvent actionEvent) {
        String dashboardFXML = "Dashboard.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(dashboardFXML));
        try {
            Parent dashboardParent = loader.load();
            Scene dashboardScene = new Scene(dashboardParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + dashboardFXML, e);
        }
    }
}
