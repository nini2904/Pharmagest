package com.example.login;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
//import Medicament;
//import TransactionItem;
//import DatabaseConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VenteController {

    @FXML private ComboBox<String> medicamentComboBox; // ComboBox for medications

    @FXML private TextField quantityField;
    @FXML private TableView<TransactionItem> itemsTable;
    @FXML private TableColumn<TransactionItem, String> DCIColumn;
    @FXML private TableColumn<TransactionItem, Double> medicamentPriceColumn;
    @FXML private TableColumn<TransactionItem, Integer> quantityColumn;
    @FXML private TableColumn<TransactionItem, Double> totalColumn;
    @FXML private Label statusLabel;
    @FXML private Button removeButton;
    @FXML private Label grandTotalLabel; // Link to the FXML Label

    private final ObservableList<TransactionItem> transactionItems = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Initialize table columns
        DCIColumn.setCellValueFactory(new PropertyValueFactory<>("DCI"));
        medicamentPriceColumn.setCellValueFactory(new PropertyValueFactory<>("prixVente"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantiteVendue"));
        totalColumn.setCellValueFactory(cellData -> {
            TransactionItem item = cellData.getValue();
            return new ReadOnlyObjectWrapper<>(item.getTotal());
        });
        // Align totalColumn to the right with two decimal places
        medicamentPriceColumn.setCellFactory(column -> new TableCell<TransactionItem, Double>() {
            @Override
            protected void updateItem(Double total, boolean empty) {
                super.updateItem(total, empty);
                if (empty || total == null) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", total)); // Format to 2 decimal places
                    setStyle("-fx-alignment: CENTER-RIGHT;"); // Align to right
                }
            }
        });
        totalColumn.setCellValueFactory(cellData -> cellData.getValue().totalProperty().asObject());

        // Align totalColumn to the right with two decimal places
        totalColumn.setCellFactory(column -> new TableCell<TransactionItem, Double>() {
            @Override
            protected void updateItem(Double total, boolean empty) {
                super.updateItem(total, empty);
                if (empty || total == null) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", total)); // Format to 2 decimal places
                    setStyle("-fx-alignment: CENTER-RIGHT;"); // Align to right
                }
            }
        });        // Enable table view editing
        itemsTable.setEditable(true);

        // Set the quantity column to be editable
        quantityColumn.setCellFactory(column -> new TableCell<TransactionItem, Integer>() {
            @Override
            protected void updateItem(Integer quantity, boolean empty) {
                super.updateItem(quantity, empty);
                if (empty || quantity == null) {
                    setText(null);
                } else {
                    setText(quantity.toString());
                    setStyle("-fx-alignment: CENTER-RIGHT;"); // Align text to right
                }

                // Make the cell editable
                setOnMouseClicked(event -> {
                    if (event.getClickCount() == 2 && !isEmpty()) {
                        // Create a TextField to edit the value
                        TextField textField = new TextField(getText());
                        textField.setOnAction(e -> {
                            try {
                                int newValue = Integer.parseInt(textField.getText());
                                if (newValue > 0) {
                                    commitEdit(newValue);
                                    TransactionItem item = getTableView().getItems().get(getIndex());
                                    item.setQuantiteVendue(newValue); // Update model
                                    updateGrandTotal(); // Refresh grand total
                                    statusLabel.setText("Quantity updated successfully!");
                                } else {
                                    statusLabel.setText("Quantity must be greater than 0.");
                                }
                            } catch (NumberFormatException ex) {
                                statusLabel.setText("Invalid quantity entered.");
                            }
                        });
                        setGraphic(textField);
                        textField.requestFocus();
                    }
                });
            }

            @Override
            public void startEdit() {
                super.startEdit();
                TextField textField = new TextField(getText());
                setGraphic(textField);
                textField.requestFocus();
                textField.setOnAction(e -> {
                    try {
                        int newValue = Integer.parseInt(textField.getText());
                        commitEdit(newValue);
                        TransactionItem item = getTableView().getItems().get(getIndex());
                        item.setQuantiteVendue(newValue);
                        updateGrandTotal();
                        statusLabel.setText("Quantity updated successfully!");
                    } catch (NumberFormatException ex) {
                        statusLabel.setText("Invalid quantity entered.");
                    }
                });
            }

            @Override
            public void cancelEdit() {
                super.cancelEdit();
                setGraphic(null);
                setText(getItem().toString());
            }
        });

        quantityColumn.setOnEditCommit(event -> {
            TransactionItem item = event.getRowValue();
            int newValue = event.getNewValue();
            item.setQuantiteVendue(newValue); // Update the model
            updateGrandTotal(); // Recalculate the total
        });
        // Update the grand total whenever the transactionItems list changes
        transactionItems.addListener((ListChangeListener<TransactionItem>) change -> {
            updateGrandTotal();
        });

        // Bind the "Enlever médicament" button's disable property to the selection state
        removeButton.disableProperty().bind(itemsTable.getSelectionModel().selectedItemProperty().isNull());

        // Enable table view editing
        itemsTable.setEditable(true);
        // Set the quantity column to be editable
        itemsTable.setItems(transactionItems);
        refreshMedicamentComboBox(); // Load initial ComboBox items


    }

    // Load medication names from the Medicament table into the ComboBox
    private void loadMedicamentData() {
        List<String> medicamentList = new ArrayList<>();
        DatabaseConnection connectNow = new DatabaseConnection();
        try (Connection conn = connectNow.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("SELECT DCI FROM medicament");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                medicamentList.add(rs.getString("DCI"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Error loading medications: " + e.getMessage());
        }

        // Populate ComboBox with the retrieved list
        ObservableList<String> observableList = FXCollections.observableArrayList(medicamentList);
        medicamentComboBox.setItems(observableList);
    }

    public void addItem() {
        String medicamentIdStr = medicamentComboBox.getValue();
        String quantityStr = quantityField.getText();

        if (medicamentIdStr == null || medicamentIdStr.isBlank()) {
            statusLabel.setText("Please select a Medicament.");
            return;
        }

        if (quantityStr == null || quantityStr.isBlank()) {
            statusLabel.setText("Please enter the quantity.");
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);

            DatabaseConnection connectNow = new DatabaseConnection();

            // Validate Medicament from the database
            try (Connection conn = connectNow.getConnection()) {
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Medicament WHERE dci = ?");
                stmt.setString(1, medicamentIdStr);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    String name = rs.getString("DCI");
                    double price = rs.getDouble("prixunit_vente");

                    // Add the item to the transaction
                    TransactionItem item = new TransactionItem(name, price, quantity);
                    transactionItems.add(item);
                    statusLabel.setText("Item added successfully!");
                    itemsTable.setItems(transactionItems);

                    // Clear input fields and refresh the ComboBox
                    medicamentComboBox.setValue(null);
                    quantityField.clear();
                    refreshMedicamentComboBox();
                } else {
                    statusLabel.setText("Medicament not found.");
                }
            }
        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid input. Please enter a valid number for quantity.");
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Database error: " + e.getMessage());
        }
    }

    public void removeSelectedItem() {
        TransactionItem selectedItem = itemsTable.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            transactionItems.remove(selectedItem);
            updateGrandTotal();
            statusLabel.setText("Item removed successfully!");
            refreshMedicamentComboBox(); // Refresh the ComboBox after removal
        } else {
            statusLabel.setText("No item selected to remove.");
        }
    }

    public void finalizeSale() {
        if (transactionItems.isEmpty()) {
            statusLabel.setText("No items to sell.");
            return;
        }

        DatabaseConnection connectNow = new DatabaseConnection();
        try (Connection conn = connectNow.getConnection()) {
            // Start transaction
            conn.setAutoCommit(false);

            double grandTotal = transactionItems.stream()
                    .mapToDouble(TransactionItem::getTotal)
                    .sum();
            // Insert into Vente
            PreparedStatement venteStmt = conn.prepareStatement(
                    "INSERT INTO Vente (date_vente, montant) VALUES (CURRENT_DATE,?) RETURNING num_vente");
            venteStmt.setDouble(1, grandTotal);
            ResultSet venteRs = venteStmt.executeQuery();
            venteRs.next();
            int venteId = venteRs.getInt("num_vente");

            // Insert each item into Ligne_vendu
            PreparedStatement ligneStmt = conn.prepareStatement(
                    "INSERT INTO Ligne_vendu (num_vente, medicament_dci, prixunit_vente, qte_vendue) VALUES (?, ?, ?, ?)");
            for (TransactionItem item : transactionItems) {
                ligneStmt.setInt(1, venteId);
                ligneStmt.setString(2, item.getDCI());
                ligneStmt.setDouble(3, item.getPrixVente());
                ligneStmt.setInt(4, item.getQuantiteVendue());
                ligneStmt.addBatch();
            }
            ligneStmt.executeBatch();

            // Commit transaction
            conn.commit();
            transactionItems.clear();
            statusLabel.setText("Sale finalized successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Error finalizing sale: " + e.getMessage());
        }
    }

    private void updateGrandTotal() {
        double grandTotal = transactionItems.stream()
                .mapToDouble(TransactionItem::getTotal)
                .sum();
        grandTotalLabel.setText(String.format("Grand Total: %.2f", grandTotal));
    }

    private void refreshMedicamentComboBox() {
        List<String> medicamentList = new ArrayList<>();
        DatabaseConnection connectNow = new DatabaseConnection();

        try (Connection conn = connectNow.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("SELECT DCI FROM Medicament");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String medicamentName = rs.getString("DCI");

                // Exclude medications already in transactionItems
                boolean isInTransaction = transactionItems.stream()
                        .anyMatch(item -> item.getDCI().equalsIgnoreCase(medicamentName));
                if (!isInTransaction) {
                    medicamentList.add(medicamentName);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Error loading medications: " + e.getMessage());
        }

        // Update the ComboBox items
        ObservableList<String> observableList = FXCollections.observableArrayList(medicamentList);
        medicamentComboBox.setItems(observableList);
    }
    public void RetourOnAction(ActionEvent actionEvent) {
        String dashboardFXML = "Dashboard.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(dashboardFXML));
        try {
            Parent dashboardParent = loader.load();
            Scene dashboardScene = new Scene(dashboardParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + dashboardFXML, e);
        }
    }

}
